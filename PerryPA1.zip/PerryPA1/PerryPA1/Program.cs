﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerryPA1
{
    class Program
    {
        static void Main(string[] args)
        {
            // initiate values to store later
            String ShipTo;
            int Zipcode;

            // initiate and set initiated values to use in calculation
            double EnvelopesCost = .89;
            double SmallPackagesCost = 3.50;
            double Tax = .10;

            // initiate values to store later
            int EnvelopesNumber;
            int SmallPackagesNumber;
            
            // prompt user for name
                Console.Write("Enter Customer Name: ");
            ShipTo = Console.ReadLine(); 
            // store name in ShipTo value

            // propmt user for Zipcode
                Console.Write("Enter Shipping Zipcode: ");
            Zipcode = int.Parse(System.Console.ReadLine());
            // store Zipcode in Zipcode value

            // prompt user for purchase amount of Envelopes
                Console.Write("Enter a number for Envelopes to purchase: ");
            EnvelopesNumber = int.Parse(System.Console.ReadLine());
            // store Envelope amount in EnvelopeNumber value

            // prompt user for purchase amount of SmallPackages
                Console.Write("Enter a number for SmallPackages to purchase: ");
            SmallPackagesNumber = int.Parse(System.Console.ReadLine());
            // store SmallPackage amount in SmallPackageNumber

            // initiate and set calculated values stored
            double ShippingCost = EnvelopesNumber * EnvelopesCost + SmallPackagesNumber * SmallPackagesCost;
            double TotalTax = ShippingCost * Tax;
            double ShippingTotal = ShippingCost + TotalTax;

            // resaults tabled and aligned output
            Console.WriteLine("\nShip To: {0}", ShipTo.PadLeft(14));
            Console.WriteLine("Shipping Zipcode: ".PadRight(15) + Zipcode);
            Console.WriteLine("Shipping Cost: ".PadRight(20) + "{0:C}".PadLeft(2), ShippingCost);
            Console.WriteLine("Tax: ".PadRight(21) + "{0:C}".PadLeft(2), TotalTax);
            Console.WriteLine("Shipping Total: ".PadRight(20) + "{0:C}".PadLeft(1), ShippingTotal);

            // prevent self-kill
            Console.ReadKey();
        }
    }
}
