﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserPrompt;

namespace PerryPA5
{
    class Program
    {
        static void Main( string [] args )
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();

            Console.Write( "Would you like to make ship a package? (Y/N): " );
            Engine();
        }

        static void Engine()
        {
            double totalCost = 0.00;
            Package [] p = new Package [100];

            string result;
            for ( int i = 0; ( result = Console.ReadLine().ToLower() ) == "y"; i++ )
            {
                ConsolePrompt<int> Packageinfo = new ConsolePrompt<int>();

                int length = Packageinfo.PromptUser( "Enter Length (in inches): " );
                int width = Packageinfo.PromptUser( "Enter Width  (in inches): " );
                int height = Packageinfo.PromptUser( "Enter Height (in inches): " );

                double weight = Packageinfo.PromptUser<double>( "Enter Weight (in inches): " );

                p[i] = new Package( length, width, height, weight );
                p[i].PrintReceipt();
                totalCost += p[i].Cost();

                Console.Write( "Would you like to ship another package? (Y/N): " );
            }

            if ( result == "n" )
            {
                Console.Write( $"Your total shipping cost:" );
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine( $"{totalCost:C}".PadLeft( 30 ) );
                Console.ReadKey();
            }

            if ( result != "y" && result != "n" )
            {
                ConsoleColor temp;
                temp = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write( "invalid, try again: " );
                Console.ForegroundColor = temp;
                Engine();
            }
        }
    }
}
