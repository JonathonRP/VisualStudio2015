﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace UserPrompt
{

    /// <summary>
    /// Prompts the user for input : may be used as object
    /// </summary>
    /// <typeparam name="T"></typeparam>

    public class ConsolePrompt<T>
    {

        /// <summary>
        /// Constructor for ConsolePrompt object
        /// </summary>

        public ConsolePrompt()
        {

        }

        /// <summary>
        /// Prompts user for input and returns input for storage into variable
        /// </summary>
        /// <param name="prompt"></param>
        /// <returns>value to store into variable</returns>

        public static T Prompt( string prompt )
        {
            Console.Write( prompt );
            object response = Console.ReadLine();

            T value;
            bool result = TryParse<T>( response, out value );

            while ( result == false )
            {
                ConsoleColor newDefault;
                newDefault = Console.ForegroundColor;

                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write( $"{response} is invalid, Try again " );
                Console.ForegroundColor = newDefault;
                response = Console.ReadLine();
                result = TryParse<T>( response, out value );
            }
            return value;
        }

        /// <summary>
        /// Prompts user for input and returns input for storage into variable with a changed type
        /// </summary>
        /// <typeparam name="S"></typeparam>
        /// <param name="prompt"></param>
        /// <returns>value to store into variable of a differnt type</returns>

        public static S Prompt<S>( string prompt )
        {
            Console.Write( prompt );
            object response = Console.ReadLine();

            S value;
            bool result = TryParse<S>( response, out value );

            while ( result == false )
            {
                ConsoleColor newDefault;
                newDefault = Console.ForegroundColor;

                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write( $"{response} is invalid, Try again " );
                Console.ForegroundColor = newDefault;
                response = Console.ReadLine();
                result = TryParse<S>( response, out value );
            }
            return value;
        }

        /// <summary>
        /// Prompts user for input and passes input out to a variable.
        /// </summary>
        /// <param name="prompt"></param>
        /// <param name="value"></param>

        static void Prompt<S>( string prompt, out S value )
        {
            Console.Write( prompt );

            object response = Console.ReadLine();

            bool result = TryParse<S>( response, out value );

            while ( result == false )
            {
                ConsoleColor newDefault;
                newDefault = Console.ForegroundColor;

                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write( $"{response} is invalid, Try again " );
                Console.ForegroundColor = newDefault;
                response = Console.ReadLine();
                result = TryParse<S>( response, out value );
            }
        }

        /// <summary>
        /// Prompts user for input and returns input to be stored into variable. When ConsolePompt is used as an object
        /// </summary>
        /// <param name="prompt"></param>
        /// <returns>value to store into variable</returns>

        public T PromptUser( string prompt )
        {
            T value = Prompt( prompt );
            return value;
        }

        /// <summary>
        /// Prompts user for input and returns input to be stored into variable with a changed type. When ConsolePompt is used as an object
        /// </summary>
        /// <typeparam name="S"></typeparam>
        /// <param name="prompt"></param>
        /// <returns>value to store into variable of changed type</returns>

        public S PromptUser<S>( string prompt )
        {
            S value = Prompt<S>( prompt );
            return value;
        }

        /// <summary>
        /// Prompts user for two inputs to pass to two variables
        /// </summary>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>

        public static void Prompt( string prompt, out T value, string prompt2, out T value2 )
        {
            Prompt( prompt, out value );

            Prompt( prompt2, out value2 );
        }

        /// <summary>
        /// Prompts user for three inputs to pass to three variables
        /// </summary>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>

        public static void Prompt( string prompt, out T value, string prompt2, out T value2, string prompt3, out T value3 )
        {
            Prompt( prompt, out value );

            Prompt( prompt2, out value2 );

            Prompt( prompt3, out value3 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables
        /// </summary>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt( string prompt, out T value, string prompt2, out T value2, string prompt3, out T value3, string prompt4, out T value4 )
        {
            Prompt( prompt, out value );

            Prompt( prompt2, out value2 );

            Prompt( prompt3, out value3 );

            Prompt( prompt4, out value4 );
        }

        /// <summary>
        /// Prompts user for two inputs to pass to two variables of a different type
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>

        public static void Prompt<U>( string prompt, out T value, string prompt2, out U value2 )
        {
            Prompt( prompt, out value );

            Prompt<U>( prompt2, out value2 );
        }

        /// <summary>
        /// Prompts user for three inputs to pass to three variables with one of type U
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>

        public static void Prompt<U>( string prompt, out T value, string prompt2, out T value2, string prompt3, out U value3 )
        {
            Prompt( prompt, out value );

            Prompt( prompt2, out value2 );

            Prompt<U>( prompt3, out value3 );
        }

        /// <summary>
        /// Prompts user for three inputs to pass to three variables with two of type U
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>

        public static void Prompt<U>( string prompt, out T value, string prompt2, out U value2, string prompt3, out U value3 )
        {
            Prompt( prompt, out value );

            Prompt<U>( prompt2, out value2 );

            Prompt<U>( prompt3, out value3 );
        }

        /// <summary>
        /// Prompts user for three inputs to pass to three variables with two different types
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <typeparam name="V"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>

        public static void Prompt<U, V>( string prompt, out T value, string prompt2, out U value2, string prompt3, out V value3 )
        {
            Prompt( prompt, out value );

            Prompt<U>( prompt2, out value2 );

            Prompt<V>( prompt3, out value3 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables with one of type U
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt<U>( string prompt, out T value, string prompt2, out T value2, string prompt3, out T value3, string prompt4, out U value4 )
        {
            Prompt( prompt, out value );

            Prompt( prompt2, out value2 );

            Prompt( prompt3, out value3 );

            Prompt<U>( prompt4, out value4 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables with two of type U
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt<U>( string prompt, out T value, string prompt2, out T value2, string prompt3, out U value3, string prompt4, out U value4 )
        {
            Prompt( prompt, out value );

            Prompt( prompt2, out value2 );

            Prompt<U>( prompt3, out value3 );

            Prompt<U>( prompt4, out value4 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables with three of type U
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt<U>( string prompt, out T value, string prompt2, out U value2, string prompt3, out U value3, string prompt4, out U value4 )
        {
            Prompt( prompt, out value );

            Prompt<U>( prompt2, out value2 );

            Prompt<U>( prompt3, out value3 );

            Prompt<U>( prompt4, out value4 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables with two of differnt types: U and V
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <typeparam name="V"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt<U, V>( string prompt, out T value, string prompt2, out T value2, string prompt3, out U value3, string prompt4, out V value4 )
        {
            Prompt( prompt, out value );

            Prompt( prompt2, out value2 );

            Prompt<U>( prompt3, out value3 );

            Prompt<V>( prompt4, out value4 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables with two of type U and one of type V
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <typeparam name="V"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt<U, V>( string prompt, out T value, string prompt2, out U value2, string prompt3, out U value3, string prompt4, out V value4 )
        {
            Prompt( prompt, out value );

            Prompt<U>( prompt2, out value2 );

            Prompt<U>( prompt3, out value3 );

            Prompt<V>( prompt4, out value4 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables with one of type U and two of type V
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <typeparam name="V"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt<U, V>( string prompt, out T value, string prompt2, out U value2, string prompt3, out V value3, string prompt4, out V value4 )
        {
            Prompt( prompt, out value );

            Prompt<U>( prompt2, out value2 );

            Prompt<V>( prompt3, out value3 );

            Prompt<V>( prompt4, out value4 );
        }

        /// <summary>
        /// Prompts user for four inputs to pass to four variables of different types
        /// </summary>
        /// <typeparam name="U"></typeparam>
        /// <typeparam name="V"></typeparam>
        /// <typeparam name="W"></typeparam>
        /// <param name="prompt"></param>
        /// <param name="value"></param>
        /// <param name="prompt2"></param>
        /// <param name="value2"></param>
        /// <param name="prompt3"></param>
        /// <param name="value3"></param>
        /// <param name="prompt4"></param>
        /// <param name="value4"></param>

        public static void Prompt<U, V, W>( string prompt, out T value, string prompt2, out U value2, string prompt3, out V value3, string prompt4, out W value4 )
        {
            Prompt( prompt, out value );

            Prompt<U>( prompt2, out value2 );

            Prompt<V>( prompt3, out value3 );

            Prompt<W>( prompt4, out value4 );
        }

        private static bool TryParse<Z>( object input, out Z value )
        {
            try
            {
                value = (Z) Convert.ChangeType( input, typeof( Z ) );
                return true;
            }
            catch
            {

                value = default( Z );
                return false;
            }

        }
    }
}