﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PerryHMK03
{
    public partial class Form1 : Form
    {        
        public Form1()
        {
            InitializeComponent();
        }

        int count = 0;

        private void PressMe_MouseDown(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void PressMe_MouseUp(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.DodgerBlue;
        }

        private void ClickMe_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
            label1.Text = $"Clicks counted: {count += 1}";
        }

        private void Form1_BackColorChanged(object sender, EventArgs e)
        {            
            if (BackColor == Color.Yellow)
            {
                label1.Text = $"Clicks counted: {count += 1}";
            }
        }
    }
}
