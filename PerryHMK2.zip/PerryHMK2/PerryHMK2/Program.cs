﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyPrompts;

namespace PerryHMK2
{
    class Program
    {
        static void Main(string[] args)
        {
            PrettyConsole();
            ConsoleColor reset = Console.ForegroundColor;

            var data = Input("Enter a string of comma separated values \n >> ", ConsoleColor.Red);

            while (data == "")
            {
                MessageBox.Show("Please enter a value", "Try Again", MessageBoxButtons.OK, MessageBoxIcon.Error);
                PrettyConsole();
                data = Input("Enter a string of comma separated values \n >> ", ConsoleColor.Red);
            }

            var nums = data.Split(',').GetNumericValues<double>();

            Console.ForegroundColor = reset;

            Print($"I counted {nums.Count()} numbers, with an Average of {nums.Average():F2}", newline: true);
            Print($"The minimum value over 100 is {nums.Where(x => x > 100).Min()}\n", newline: true);
            Print("Press any key to exit");
            Console.ReadKey();
        }
        static void PrettyConsole()
        {
            ConsoleColor defualt = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;

            Console.ForegroundColor = defualt;
            Console.Clear();
        }
        public static void Print(string prompt, ConsoleColor color = ConsoleColor.Black, bool newline = false)
        {
            Console.ForegroundColor = color;

            if (newline == true)
                Console.WriteLine(prompt);
            else
                Console.Write(prompt);
        }
        public static string Input(string prompt, ConsoleColor color = ConsoleColor.Black)
        {
            Print(prompt);
            Console.ForegroundColor = color;
            return Console.ReadLine();
        }
    }

    public static class Object : System.Object
    {
        public static IEnumerable<T> GetNumericValues<T>(this object[] input, T value = default(T))
        {
            return input.SelectMany(s => TryParse(s, out value) ? new[] { value } : new T[0]);
        }
        public static R Parse<R>(object input)
        {
            return (R)Convert.ChangeType(input, typeof(R));
        }
        public static Boolean TryParse<S>(object input, out S value)
        {
            try
            {
                value = Object.Parse<S>(input);
                return true;
            }
            catch
            {
                value = default(S);
                return false;
            }
        }
    }
}
