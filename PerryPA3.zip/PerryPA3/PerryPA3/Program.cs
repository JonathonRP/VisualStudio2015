﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerryPA3
{
    class Program
    {
        static void Main( string [] args )
        {

            Package customer = new Package();
            customer.PrintShipping();

            Package myPackage = new Package( 4, 5, 6, 1.5 );
            myPackage.PrintShipping();

            Console.ReadKey();
        }
    }
}
