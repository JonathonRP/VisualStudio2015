﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerryPA3
{
    class Package
    {

        private double height, length, width, weight;

        public Package(){

            length = Prompt( " Enter Length in inches: " );
            width = Prompt( " Enter width in inches: " );
            height = Prompt( " Enter height in inches: " );

            weight = Prompt( " Enter weight in pounds: " );

        }

        private double Prompt( string prompt )
        {
            double response;
            Console.Write( prompt );
            response = double.Parse( Console.ReadLine() );

            return response;
        }

        public Package( double newHeight, double newLength, double newWidth, double newWeight ){

            height = newHeight;
            length = newLength;
            width = newWidth;
            weight = newWeight;

        }

        public double ShippingCost()
        {
            double cubicInches = length * width * height;
            double cost = ( 5 * weight ) + (.01 * cubicInches);

            return cost;
        }

        public void PrintShipping()
        {

            Console.WriteLine( "\nThe {0}x{1}x{2} inch package at {3} lb(s) will cost {4:C} to ship", length, width, height, weight, ShippingCost());

        }

    }
}
