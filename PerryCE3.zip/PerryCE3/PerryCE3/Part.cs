﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerryCE3
{
    class Part
    {
        private double costPerPart;
        private int quantity;
        private string name;

        public double CostPerPart
        {
            get
            {
                return costPerPart;
            }

            set
            {
                costPerPart = value;
            }
        }
        public int Quality
        {
            get
            {
                return quantity;
            }

            set
            {
                quantity = value;
            }
        }
        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public Part ()
        {
            name = "unknown";
        }

        public Part( string newName, double newCostPerPart, int newQuantity )
        {
            costPerPart = newCostPerPart;
            quantity = newQuantity;
            name = newName;
        }

        public double Cost ()
        {
            return costPerPart * quantity;
        }

        public override string ToString()
        {
            string DataMembers = string.Format ("Name: {0} \nPerPart Cost: {1} \nDesired Quanity: {2} \nTotal Cost: {3} \n", name, costPerPart, quantity, Cost());
            return DataMembers;
        }
    }
}
